# Release notes

## 2025.2.0-52

- Bring out database migrations and nginx config generation
  to separate scripts so that they can be run independently
  during init container phase.
- Use Loci Skyline image by default.

### New Features

- Update default ingress classes and annotations for charts to make them implementation
  agnostic. They used to be nginx specific because we always used ingress-nginx as the most
  common choice. Ingress-nginx is deprecated and will become unmaintained in Feb/2026.
  
  Now for all test jobs we use HAProxy Ingress as the default implementation. However any
  other implementation can be used as far as it suppports annotations similar to
  'nginx.ingress.kubernetes.io/rewrite-target' or 'haproxy.org/path-rewrite' which are
  used in many OpenStack-Helm charts.

### Bug Fixes

- Mount Skyline apiserver socket directory to the nginx container.
  
  The Skyline pods have two containers: nginx and skyline apiserver.
  The nginx container needs access to the apiserver socket to proxy
  requests to it.

## 2025.2.0

- Adding a missing oci_image_registry endpoint and secret in the Skyline Helm
  chart.
- Initial release of the Skyline chart
- Fix db-sync container image tag variable to match the style of all other
  charts to be prefixed with the project name.

### New Features

- Update apparmor values to use security_context instead of annotations.
- Add support for runtimeClassName and priorityClassName

## 2025.1.0

## 2024.2.0

Before 2024.2.0 all the OpenStack-Helm charts were versioned independently.
Here we provide all the release notes for the chart for all versions before 2024.2.0.
