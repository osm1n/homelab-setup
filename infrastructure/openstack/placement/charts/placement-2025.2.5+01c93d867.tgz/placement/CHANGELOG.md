# Release notes

## 2025.2.0-52

### New Features

- Update default ingress classes and annotations for charts to make them implementation
  agnostic. They used to be nginx specific because we always used ingress-nginx as the most
  common choice. Ingress-nginx is deprecated and will become unmaintained in Feb/2026.
  
  Now for all test jobs we use HAProxy Ingress as the default implementation. However any
  other implementation can be used as far as it suppports annotations similar to
  'nginx.ingress.kubernetes.io/rewrite-target' or 'haproxy.org/path-rewrite' which are
  used in many OpenStack-Helm charts.

## 2025.2.0

### New Features

- Update apparmor values to use security_context instead of annotations.
- Add support for runtimeClassName and priorityClassName

## 2025.1.0

## 2024.2.0

Before 2024.2.0 all the OpenStack-Helm charts were versioned independently.
Here we provide all the release notes for the chart for all versions before 2024.2.0.

- 0.1.0 Initial Chart
- 0.1.1 Change helm-toolkit dependency version to ">= 0.1.0"
- 0.1.2 Establish Nova/Placement dependencies
- 0.1.3 Use proper default placement image
- 0.1.4 Add null check condition in placement deployment manifest
- 0.1.5 Change Issuer to ClusterIssuer
- 0.1.6 Revert - Change Issuer to ClusterIssuer
- 0.1.7 Change Issuer to ClusterIssuer
- 0.2.0 Remove support for releases before T
- 0.2.1 Add Ussuri release support
- 0.2.2 Add Victoria and Wallaby releases support
- 0.2.3 Added helm.sh/hook annotations for Jobs
- 0.2.4 Helm 3 - Fix Job Labels
- 0.2.5 Update htk requirements repo
- 0.2.6 Enable taint toleration for Openstack services
- 0.2.7 Add helm hook annotations for db-sync job
- 0.2.8 Migrated PodDisruptionBudget resource to policy/v1 API version
- 0.2.9 Add Xena and Yoga values overrides
- 0.2.10 Added OCI registry authentication
- 0.2.11 Distinguish between port number of internal endpoint and binding port number
- 0.2.12 Use HTTP probe instead of TCP probe
- 0.2.13 Support TLS endpoints
- 0.3.0 Remove placement-migrate
- 0.3.1 Remove support for Train and Ussuri
- 0.3.2 Remove default policy rules
- 0.3.3 Replace node-role.kubernetes.io/master with control-plane
- 0.3.4 Define service_type in keystone_authtoken to support application credentials with access rules
- 0.3.5 Add Zed overrides
- 0.3.6 Add 2023.1 overrides
- 0.3.7 Use service tokens
- 0.3.8 Add Ubuntu Jammy overrides
- 0.3.9 Add 2023.2 Ubuntu Jammy overrides
- 0.3.10 Add log_dir option for placement
- 0.3.11 Enable custom annotations for Openstack pods
- 0.3.12 Add 2024.1 overrides
- 0.3.13 Enable custom annotations for Openstack secrets
- 0.3.14 Update images used by default
- 0.3.15 Uses uWSGI for API service
- 0.3.16 Use quay.io/airshipit/kubernetes-entrypoint:latest-ubuntu_focal by default
- 0.3.17 Add 2024.2 Ubuntu Jammy overrides
- 0.3.18 Update Chart.yaml apiVersion to v2
- 2024.2.0 Update version to align with the Openstack release cycle
